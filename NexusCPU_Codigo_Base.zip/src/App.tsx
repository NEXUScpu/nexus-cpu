import React, { useState } from 'react';
import BinaryLab from './components/BinaryLab';
import DatapathLab from './components/DatapathLab';

export default function App() {
  const [activeTab, setActiveTab] = useState<'binary' | 'datapath' | 'mesi' | 'matrix'>('binary');

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      <header className="border-b border-slate-800 bg-slate-900/60 backdrop-blur px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-3 h-3 bg-emerald-500 rounded-full animate-pulse"></div>
          <h1 className="text-xl font-bold tracking-wider bg-gradient-to-r from-sky-400 to-indigo-400 bg-clip-text text-transparent">
            NexusCPU <span className="text-xs text-slate-400 font-normal">v1.0</span>
          </h1>
        </div>

        <nav className="flex flex-wrap justify-center gap-1 bg-slate-950/50 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('binary')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'binary'
                ? 'bg-sky-600 text-white shadow-lg shadow-sky-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            Texto a Binario
          </button>

          <button
            onClick={() => setActiveTab('datapath')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'datapath'
                ? 'bg-sky-600 text-white shadow-lg shadow-sky-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            Datapath Visual
          </button>

          <button
            onClick={() => setActiveTab('mesi')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'mesi'
                ? 'bg-sky-600 text-white shadow-lg shadow-sky-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            Multi-Core MESI
          </button>

          <button
            onClick={() => setActiveTab('matrix')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'matrix'
                ? 'bg-sky-600 text-white shadow-lg shadow-sky-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            Matriz & Loop Tiling
          </button>
        </nav>
      </header>

      <main className="flex-1 p-6 max-w-7xl mx-auto w-full">
        {activeTab === 'binary' && <BinaryLab />}
        {activeTab === 'datapath' && <DatapathLab />}

        {activeTab === 'mesi' && (
          <div className="flex flex-col items-center justify-center border-2 border-dashed border-slate-800 rounded-2xl p-12 bg-slate-900/20 text-center my-6">
            <h2 className="text-2xl font-semibold mb-2 text-indigo-400">Simulador Multi-Core MESI</h2>
            <p className="text-slate-400 max-w-md mb-6">
              Módulo en preparación para la coherencia de caché entre núcleos.
            </p>
          </div>
        )}

        {activeTab === 'matrix' && (
          <div className="flex flex-col items-center justify-center border-2 border-dashed border-slate-800 rounded-2xl p-12 bg-slate-900/20 text-center my-6">
            <h2 className="text-2xl font-semibold mb-2 text-emerald-400">Laboratorio de Matrices</h2>
            <p className="text-slate-400 max-w-md mb-6">
              Módulo en preparación para el mapa de calor de Loop Tiling.
            </p>
          </div>
        )}
      </main>

      <footer className="border-t border-slate-800/80 py-4 text-center text-xs text-slate-500">
        NexusCPU &bull; Simulador de Arquitectura de Computadoras II
      </footer>
    </div>
  );
}
